<?php
/**
 * Plugin Name: PPGD(Product Payment-Gateway Disabled)
 * Plugin URI:  https://yourwebsite.com
 * Description: Allows admin to disable payment gateways for a specific product from the frontend and enable/disable it whenever needed.
 * Version:     1.3
 * Author:      Akshay Upadhyay
 * Author URI:  https://yourwebsite.com
 * License:     GPL2
 * Text Domain: Product Payment-Gateway Disabled Plugin
 */

// Hook to add menu item in the admin menu
function fdp_admin_menu() {
    add_menu_page(
        'Frontend Disable Payment Gateways',
        'Disable Payment Gateways',
        'manage_options',
        'frontend-disable-payment-gateways',
        'fdp_main_menu_page',
        'dashicons-cart',
        56
    );
    add_submenu_page(
        'frontend-disable-payment-gateways',
        'Product ID Settings',
        'Product ID Settings',
        'manage_options',
        'frontend-disable-payment-gateways-settings',
        'fdp_settings_page'
    );
}
add_action( 'admin_menu', 'fdp_admin_menu' );

// Register settings
function fdp_register_settings() {
    register_setting( 'fdp_settings_group', 'fdp_product_ids' ); 
    register_setting( 'fdp_settings_group', 'fdp_disable_payment_gateways' );
    register_setting( 'fdp_settings_group', 'fdp_enable_payment_gateways' );
}
add_action( 'admin_init', 'fdp_register_settings' );

// Create the settings page for the submenu
function fdp_settings_page() {
    // Handle form submission
    if ( isset( $_POST['fdp_product_ids'] ) ) {
        $submitted_ids = sanitize_text_field( $_POST['fdp_product_ids'] );

        // Append the new IDs to the existing option
        if ( ! empty( $submitted_ids ) ) {
            $existing_ids = get_option( 'fdp_product_ids', '' );
            $existing_ids_array = ! empty( $existing_ids ) ? explode( ',', $existing_ids ) : [];
            $new_ids_array = explode( ',', $submitted_ids );

            // Merge arrays and ensure unique product IDs
            $all_ids = array_unique( array_merge( $existing_ids_array, array_map( 'trim', $new_ids_array ) ) );

            // Update the option with the new list
            update_option( 'fdp_product_ids', implode( ',', $all_ids ) );
        }

        // Show success message
        echo '<div class="updated"><p>Product IDs have been saved successfully.</p></div>';
    }

    ?>
    <div class="wrap">
        <h1>Disable Payment Gateways for Specific Products</h1>
        <form method="post">
            <?php settings_fields( 'fdp_settings_group' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Product IDs (Comma Separated)</th>
                    <td>
                        <input type="text" name="fdp_product_ids" value="" placeholder="Enter product IDs here" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Disable Payment Gateways</th>
                    <td>
                        <input type="checkbox" name="fdp_disable_payment_gateways" value="1" <?php checked( get_option( 'fdp_disable_payment_gateways' ), 1 ); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Enable Payment Gateways</th>
                    <td>
                        <input type="checkbox" name="fdp_enable_payment_gateways" value="1" <?php checked( get_option( 'fdp_enable_payment_gateways' ), 1 ); ?> />
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>

        <h2>Disabled Product IDs</h2>
        <ul>
            <?php
            $disabled_product_ids = get_option( 'fdp_product_ids', '' );
            if ( ! empty( $disabled_product_ids ) ) {
                $product_ids = explode( ',', $disabled_product_ids );
                foreach ( $product_ids as $product_id ) {
                    echo '<li>Product ID: <strong>' . esc_html( trim( $product_id ) ) . '</strong></li>';
                }
            } else {
                echo '<li>No disabled product IDs found.</li>';
            }
            ?>
        </ul>
    </div>
    <?php
}


// Disable payment gateways for specific product IDs
function fdp_disable_payment_gateways_for_product( $available_gateways ) {
    if ( is_admin() || ! WC()->cart ) {
        return $available_gateways;
    }

    $product_ids_to_disable = get_option( 'fdp_product_ids' );
    $disable_gateways = get_option( 'fdp_disable_payment_gateways' );

    if ( $disable_gateways && ! empty( $product_ids_to_disable ) ) {
        $product_ids = explode( ',', $product_ids_to_disable );
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            if ( in_array( $cart_item['product_id'], $product_ids ) ) {
                $available_gateways = array(); // Disable all gateways
                break;
            }
        }
    }

    return $available_gateways;
}
add_filter( 'woocommerce_available_payment_gateways', 'fdp_disable_payment_gateways_for_product' );

// Validate cart items during checkout
function fdp_validate_cart_items_on_checkout() {
    $disabled_product_ids = get_option( 'fdp_product_ids', '' );

    if ( ! empty( $disabled_product_ids ) ) {
        $product_ids = explode( ',', $disabled_product_ids );
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            if ( in_array( $cart_item['product_id'], $product_ids ) ) {
                wc_add_notice( 'The product "' . get_the_title( $cart_item['product_id'] ) . '" is not available.', 'error' );
            }
        }
    }
}
add_action( 'woocommerce_check_cart_items', 'fdp_validate_cart_items_on_checkout' );



// Frontend form for admins to add and manage product IDs
function fdp_frontend_form() {
    if ( current_user_can( 'manage_options' ) ) {
        // Handle form submission for adding a new Product ID
        if ( isset( $_POST['fdp_new_product_id'] ) && ! empty( $_POST['fdp_new_product_id'] ) ) {
            $new_product_id = sanitize_text_field( $_POST['fdp_new_product_id'] );
            $existing_product_ids = get_option( 'fdp_product_ids', '' );

            if ( ! empty( $existing_product_ids ) ) {
                $product_ids = explode( ',', $existing_product_ids );
            } else {
                $product_ids = [];
            }

            if ( ! in_array( $new_product_id, $product_ids ) ) {
                $product_ids[] = $new_product_id;
                update_option( 'fdp_product_ids', implode( ',', $product_ids ) );
                echo '<div class="updated"><p>Product ID added successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Product ID already exists.</p></div>';
            }
        }

        ?>
        <div style="max-width: 600px; margin: 20px auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
            <h2 style="font-size: 20px; color: #333;">Add Product ID</h2>
            <form method="post">
                <label for="fdp_new_product_id" style="font-weight: bold; font-size: 16px;">Product ID:</label>
                <input type="text" name="fdp_new_product_id" id="fdp_new_product_id" style="width: 100%; padding: 8px; margin-top: 8px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #ccc;" />
                <input type="submit" value="Add Product" style="background-color: #0073aa; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;" />
            </form>
        </div>

        <div style="max-width: 600px; margin: 20px auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
            <h2 style="font-size: 20px; color: #333;">Disabled Product IDs</h2>
            <ul style="list-style-type: none; padding: 0;">
                <?php
                $disabled_product_ids = get_option( 'fdp_product_ids', '' );
                if ( ! empty( $disabled_product_ids ) ) {
                    $product_ids = explode( ',', $disabled_product_ids );
                    foreach ( $product_ids as $product_id ) {
                        echo '<li style="margin-bottom: 8px; font-size: 16px; color: #333;">Product ID: <strong>' . esc_html( trim( $product_id ) ) . '</strong></li>';
                    }
                } else {
                    echo '<li style="font-size: 16px; color: #888;">No product IDs found.</li>';
                }
                ?>
            </ul>
        </div>
        <?php
    }
}
add_shortcode( 'fdp_payment_gateway_form', 'fdp_frontend_form' );

